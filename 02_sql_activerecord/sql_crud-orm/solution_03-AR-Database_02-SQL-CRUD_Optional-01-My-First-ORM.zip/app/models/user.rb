require_relative 'record'

class User < Record
  # NOTE: TRY NOT WRITING ANY CODE HERE!
end