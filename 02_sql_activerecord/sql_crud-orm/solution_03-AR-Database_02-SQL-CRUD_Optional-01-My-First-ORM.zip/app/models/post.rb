require_relative 'record'

class Post < Record
  # NOTE: TRY NOT WRITING ANY CODE HERE!
end